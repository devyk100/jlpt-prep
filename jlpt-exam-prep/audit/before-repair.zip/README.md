# Bunpou Atlas (文法アトラス) — Clean, Distraction-Free JLPT Grammar Platform

> **Synthesized directly from:**
> - *Genki I (3rd Edition - N5)*: Lessons 1–12 (22 canonical points)
> - *Genki II (3rd Edition - N4)*: Lessons 13–23 (23 canonical points)
> - *Shin Kanzen Master N3 (文法)*: Units 1–12 & Form Classifications A–J (40 canonical points)
> - *Shin Kanzen Master N2 (文法)*: Chapters 1–26 & Functional Expressions (40 canonical points)
> 
> **Total: 125 canonical grammar points, 100% verified with full word-hover tooltips, sentence nuance breakdowns, mug-up matrices, and 4-way quiz explanations.**

---

## 🎨 Visual Identity: Pure Desk Aesthetic (Modeled after Astra's Kanji Atlas)
- **Paper Desk Palette**: Soft washi cream `#f6f4ed` background, clean card panels `#fffef9`, deep ink `#283b35` text, and hairline borders `#dfded3`.
- **Zero Distractions**: No bright rainbow badges, no candy gradients, no gamified arcade tokens. Clean scholar topbar with `文` brand mark and two-pane layout.
- **Two-Pane Scholar Desk**:
  - **Left Pane (Stream Index)**: Continuous scrollable list of grammar points with instant filter (All/Flow, N5, N4, N3, N2), search filter, and studied status rings.
  - **Right Desk (Study Area)**: Large serif typography (`Noto Serif JP`), connection formula (`接続`), in-depth nuance explanation, mug-up rule, interactive example sentences with audio, expandable sentence nuance drawer, and 4-way retention check quiz.

---

## 💡 Psychological & Pedagogical Architecture

Traditional textbooks and JLPT apps divide grammar into artificial "Chapters" or "N5 Section 1: 5 rules". When learners reach the end of a section, their brain experiences a false sense of completion (*"Yay, I finished section 1, I can close the app now!"*), leading to premature study abandonment.

**BunpouFlow solves this through the "Spiral Functional Orbit"**:
1. **Continuous Functional Progression**: Grammar is organized by expressive intent (e.g. *Chronos & Instant Transitions*, *Causal Chains & Regret*, *Conditional Horizons*, *Boundaries & Limits*, *Contrasts & Concessions*, *Certainty & Negation*, *Social Favors & Hierarchy*).
2. **Blurred Boundary Flow**: Foundational N5/N4 concepts connect directly into N3 subtleties and N2 literary nuances in an uninterrupted stream.
3. **Flow Mode vs Level View**: Toggle **Flow Mode** in the navbar to blur rigid JLPT level badges, keeping you in an unbroken focus state without false stopping milestones.

---

## ⚡ Key Features

### 1. Interactive Word-by-Word Lexical Hover
- Every single Japanese word in example sentences has an interactive hover popover.
- Displays: **Kanji reading (Furigana)**, **Romaji**, **Part of Speech (POS)**, **Precise English gloss**, and **Word-level nuances / JLPT traps** (e.g., transitive/intransitive flags, formal register notes).
- **Furigana Switcher**: Choose **All** (ruby text always visible), **Hover** (clean text, furigana appears on hover), or **Off**.

### 2. Sentence Nuance & JLPT Trap Drawers
- Beneath each sentence, click **"Sentence Nuance & Traps"** to reveal:
  - **Word-for-Word Literal Breakdown**: To understand the exact grammatical mechanics.
  - **Contextual Nuance**: Why this specific grammar pattern was chosen over alternatives.
  - **JLPT Trap Warning**: What makes this sentence testable (e.g., prohibited volitional endings, past tense restrictions).
- **Native Audio Speech**: Click the audio icon to hear natural Japanese pronunciation generated via the browser's native Web Speech Synthesis API (`ja-JP`).

### 3. High-Yield "Mug-Up" Cheat Matrices (暗記テーブル)
Available via the top navbar **Cheat Tables** button or embedded inside relevant lessons:
- **Te-Form & Ta-Form Conjugation Matrix**: Full conjugation formulas for Group 1 (う・つ・る, む・ぶ・ぬ, く/ぐ, す), Group 2 (る), and Group 3 (する・くる), highlighting exceptions like 行く → 行って.
- **The 4 Conditionals Decoded**: Systematic comparison of **と vs ば vs たら vs なら** with volitional rules and past tense restrictions.
- **Giving & Receiving Triad (授受動詞)**: **あげる vs くれる vs もらう** with subject-recipient directional rules and keigo counterparts.
- **Voice Transformation Ladder**: Active → Passive (受身 & 迷惑受身) → Causative (使役) → Causative-Passive (使役受身 - being forced to do against will!).
- **Keigo Survival Matrix**: Side-by-side comparison of **尊敬語 (Honorific)** vs **謙譲語 (Humble)** with in-group / out-group rules.
- **Time Sequence Nuance Spectrum**: Graded scale from 〜とき to 〜うちに, 〜最中に, 〜たとたん, 〜かと思うと, 〜か〜ないかのうちに, and 〜次第.

### 4. Retention Check Quizzes with 4-Way Option Explanations
- Interactive multiple-choice questions after each grammar point.
- **Immediate Feedback**: Select an option to see instant verification.
- **Exhaustive Explanations for EVERY Option**:
  - Why Option 1 is Correct or Wrong.
  - Why Option 2 is Correct or Wrong (e.g., "Violates volitional prohibition in main clause").
  - Why Option 3 is Correct or Wrong (e.g., "Ungrammatical connection stem").
  - Why Option 4 is Correct or Wrong (e.g., "Nuance clash with positive context").

### 5. Mistake Bank & Weak Point Drill
- Any quiz question you miss is automatically saved into your **Mistake Bank**.
- Click the bookmark icon in the navbar to open your targeted drill drawer.
- Practice your weak points anytime until 100% mastered.

### 6. Command Palette / Instant Search (`⌘K` or `Ctrl+K`)
- Instant live search by Japanese grammar pattern (e.g., `わけ`, `にしたがって`), English keyword (`regret`, `before`, `condition`), or JLPT level.

---

## 🚀 Quick Start

### One-Click Launch (Windows)
Double-click `start-platform.bat` inside `c:\JLPT\jlpt-exam-prep`.

### Manual CLI Launch
```powershell
cd c:\JLPT\jlpt-exam-prep
npm.cmd run dev
```
Open your browser at:
```
http://localhost:5173
```

@echo off
title BunpouFlow - JLPT Grammar Platform
cd /d "%~dp0"
echo ========================================================
echo   Starting BunpouFlow JLPT Grammar Mastery Platform...
echo ========================================================
echo Opening browser at http://localhost:5173 ...
start http://localhost:5173
npm.cmd run dev
pause


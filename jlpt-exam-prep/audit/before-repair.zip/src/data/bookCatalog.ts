export interface BookSource {
  id: string;
  name: string;
  level: 'N5' | 'N4' | 'N3' | 'N2';
  description: string;
  sections: {
    name: string;
    grammarIds: string[];
  }[];
}

export const BOOK_SOURCES: BookSource[] = [
  {
    "id": "genki-1",
    "name": "Genki I (3rd Ed.)",
    "level": "N5",
    "description": "Elementary Japanese I covering foundational sentence structures, verb classes, te-form, and basic relations (Lessons 1–12).",
    "sections": [
      {
        "name": "Core Grammar",
        "grammarIds": [
          "gp-kara-node",
          "gp-te-shimau",
          "gp-conditionals-four",
          "gp-noni-temo",
          "gp-dake-shika",
          "gp-hazuda-kamoshirenai",
          "gp-giving-receiving",
          "gp-voice-ladder",
          "gp-keigo-core",
          "gp-toki",
          "gp-nagara"
        ]
      },
      {
        "name": "Lesson 10: Winter Vacations Approaching",
        "grammarIds": [
          "g1-l10-tsumori",
          "g1-l10-adj-naru"
        ]
      },
      {
        "name": "Lesson 11: After-Vacation Plans",
        "grammarIds": [
          "g1-l11-tai-desire",
          "g1-l11-koto-ga-aru",
          "g1-l11-sugiru"
        ]
      },
      {
        "name": "Lesson 12: Feeling Sick",
        "grammarIds": [
          "g1-l12-node-objective-reason",
          "g1-l12-nakereba-ikemasen",
          "g1-l12-deshou-darou",
          "genki1-ndesu"
        ]
      },
      {
        "name": "Lesson 13: Looking for a Part-time Job",
        "grammarIds": [
          "g2-l13-potential",
          "g2-l13-shi-reasons",
          "g2-l13-te-miru",
          "g2-l13-nara-conditional",
          "genki2-kanoukei"
        ]
      },
      {
        "name": "Lesson 14: Valentine's Day",
        "grammarIds": [
          "g2-l14-hoshii",
          "g2-l14-kamoshirenai",
          "g2-l14-tara-dou-desu-ka"
        ]
      },
      {
        "name": "Lesson 15: A Trip to Nagano",
        "grammarIds": [
          "g2-l15-volitional-form",
          "g2-l15-volitional-to-omotte-iru",
          "g2-l15-relative-clauses",
          "genki2-te-oku"
        ]
      },
      {
        "name": "Lesson 16: Lost and Found",
        "grammarIds": [
          "g2-l16-to-ii-hoping",
          "g2-l16-toki-tense"
        ]
      },
      {
        "name": "Lesson 17: Grumble and Gossip",
        "grammarIds": [
          "g2-l17-hearsay-sou-desu",
          "g2-l17-tara-conditional",
          "g2-l17-nakute-mo-ii"
        ]
      },
      {
        "name": "Lesson 18: John's Part-Time Job",
        "grammarIds": [
          "g2-l18-transitive-intransitive",
          "g2-l18-to-natural-consequence",
          "g2-l18-ba-yokatta"
        ]
      },
      {
        "name": "Lesson 19: Meeting the Boss",
        "grammarIds": [
          "g2-l19-sonkeigo-verbs",
          "g2-l19-o-kudasai"
        ]
      },
      {
        "name": "Lesson 1: New Friends",
        "grammarIds": [
          "g1-l1-wa-desu",
          "g1-l1-question-ka",
          "g1-l1-noun-no-noun",
          "g1-l1-time-and-age",
          "genki1-wa-desu"
        ]
      },
      {
        "name": "Lesson 20: Mary Goes Shopping",
        "grammarIds": [
          "genki2-yasui-nikui"
        ]
      },
      {
        "name": "Lesson 21: Which Style of House?",
        "grammarIds": [
          "g2-l21-te-aru",
          "g2-l21-aida-vs-aidani"
        ]
      },
      {
        "name": "Lesson 22: Education in Japan",
        "grammarIds": [
          "g2-l22-ba-conditional",
          "g2-l22-noni-frustration"
        ]
      },
      {
        "name": "Lesson 23: Good-bye",
        "grammarIds": [
          "g2-l23-temo-even-if",
          "g2-l23-koto-ni-suru-naru"
        ]
      },
      {
        "name": "Lesson 2: Shopping",
        "grammarIds": [
          "g1-l2-kore-sore-are-dore",
          "g1-l2-kono-sono-ano-dono",
          "g1-l2-koko-soko-asoko-doko",
          "g1-l2-mo-particle",
          "g1-l2-janai-desu"
        ]
      },
      {
        "name": "Lesson 3: Making a Date",
        "grammarIds": [
          "g1-l3-masu-form",
          "g1-l3-masenka-invitation",
          "genki1-verb-groups"
        ]
      },
      {
        "name": "Lesson 4: The First Date",
        "grammarIds": [
          "g1-l4-past-forms-deshita",
          "g1-l4-location-words"
        ]
      },
      {
        "name": "Lesson 5: A Trip to Okinawa",
        "grammarIds": [
          "g1-l5-suki-kirai",
          "g1-l5-mashou-ka"
        ]
      },
      {
        "name": "Lesson 6: A Day in Robert's Life",
        "grammarIds": [
          "g1-l6-te-kudasai",
          "g1-l6-te-mo-ii",
          "g1-l6-kara-reason"
        ]
      },
      {
        "name": "Lesson 6: A Day in Robert\\",
        "grammarIds": [
          "genki1-te-form"
        ]
      },
      {
        "name": "Lesson 7: Family Picture",
        "grammarIds": [
          "g1-l7-describing-people",
          "g1-l7-adj-te-forms",
          "g1-l7-purpose-ni-iku",
          "genki1-te-iru"
        ]
      },
      {
        "name": "Lesson 8: Barbecue",
        "grammarIds": [
          "g1-l8-nai-de-kudasai",
          "g1-l8-nominalizer-no"
        ]
      },
      {
        "name": "Lesson 9: Kabuki",
        "grammarIds": [
          "g1-l9-mou-mada"
        ]
      }
    ]
  },
  {
    "id": "genki-2",
    "name": "Genki II (3rd Ed.)",
    "level": "N4",
    "description": "Elementary Japanese II bridging to intermediate: potential, favor transactions, passive, causative, and keigo (Lessons 13–23).",
    "sections": [
      {
        "name": "Core Grammar",
        "grammarIds": [
          "gp-te-shimau",
          "gp-conditionals-four",
          "gp-noni-temo",
          "gp-hazuda-kamoshirenai",
          "gp-giving-receiving",
          "gp-voice-ladder",
          "gp-keigo-core",
          "gp-nagara"
        ]
      },
      {
        "name": "Lesson 13: Looking for a Part-time Job",
        "grammarIds": [
          "g2-l13-potential",
          "g2-l13-shi-reasons",
          "g2-l13-te-miru",
          "g2-l13-nara-conditional",
          "genki2-kanoukei"
        ]
      },
      {
        "name": "Lesson 14: Valentine's Day",
        "grammarIds": [
          "g2-l14-hoshii",
          "g2-l14-kamoshirenai",
          "g2-l14-tara-dou-desu-ka"
        ]
      },
      {
        "name": "Lesson 15: A Trip to Nagano",
        "grammarIds": [
          "g2-l15-volitional-form",
          "g2-l15-volitional-to-omotte-iru",
          "g2-l15-relative-clauses",
          "genki2-te-oku"
        ]
      },
      {
        "name": "Lesson 16: Lost and Found",
        "grammarIds": [
          "g2-l16-to-ii-hoping",
          "g2-l16-toki-tense"
        ]
      },
      {
        "name": "Lesson 17: Grumble and Gossip",
        "grammarIds": [
          "g2-l17-hearsay-sou-desu",
          "g2-l17-tara-conditional",
          "g2-l17-nakute-mo-ii"
        ]
      },
      {
        "name": "Lesson 18: John's Part-Time Job",
        "grammarIds": [
          "g2-l18-transitive-intransitive",
          "g2-l18-to-natural-consequence",
          "g2-l18-ba-yokatta"
        ]
      },
      {
        "name": "Lesson 19: Meeting the Boss",
        "grammarIds": [
          "g2-l19-sonkeigo-verbs",
          "g2-l19-o-kudasai"
        ]
      },
      {
        "name": "Lesson 20: Mary Goes Shopping",
        "grammarIds": [
          "genki2-yasui-nikui"
        ]
      },
      {
        "name": "Lesson 21: Which Style of House?",
        "grammarIds": [
          "g2-l21-te-aru",
          "g2-l21-aida-vs-aidani"
        ]
      },
      {
        "name": "Lesson 22: Education in Japan",
        "grammarIds": [
          "g2-l22-ba-conditional",
          "g2-l22-noni-frustration"
        ]
      },
      {
        "name": "Lesson 23: Good-bye",
        "grammarIds": [
          "g2-l23-temo-even-if",
          "g2-l23-koto-ni-suru-naru"
        ]
      }
    ]
  },
  {
    "id": "skm-n3",
    "name": "Shin Kanzen Master N3 Bunpou",
    "level": "N3",
    "description": "Comprehensive N3 grammar organized into 10 communicative categories and form classifications A–J.",
    "sections": [
      {
        "name": "Core Grammar",
        "grammarIds": [
          "gp-okage-sei",
          "gp-bakarini",
          "gp-monodakara",
          "gp-karaniwa",
          "gp-sae-ba",
          "gp-toshitara",
          "gp-warini-nishiteha",
          "gp-hanmen-ippou",
          "gp-wo-hajime",
          "gp-ni-watatte",
          "gp-wo-tsuujite",
          "gp-wake-trio",
          "gp-ni-chigainai",
          "gp-tamaranai-naranai",
          "gp-uchini",
          "gp-saichuu",
          "gp-totan",
          "gp-motoni-motozuite",
          "gp-ni-taishite",
          "gp-ippouda"
        ]
      },
      {
        "name": "Unit 10: 伝聞・推量 (Hearsay & Conjecture)",
        "grammarIds": [
          "skm3-u10-ni-yoru-to",
          "skm3-u10-rashii"
        ]
      },
      {
        "name": "Unit 11: 意志・計画 (Intent & Regulations)",
        "grammarIds": [
          "skm3-u11-you-to-suru-inception",
          "skm3-u11-koto-ni-natte-iru",
          "skm3-u11-koto-ni-shite-iru",
          "skm3-u11-tsumori-da"
        ]
      },
      {
        "name": "Unit 12: 敬語・待遇表現 (Politeness & Respect)",
        "grammarIds": [
          "skm3-u12-keigo-respect",
          "skm3-u12-keigo-humble"
        ]
      },
      {
        "name": "Unit 1: 時・進行 (Time & Progress)",
        "grammarIds": [
          "skm3-u1-uchini-while",
          "skm3-u1-uchini-change",
          "skm3-u1-aida-vs-aidani",
          "skm3-u1-te-kara-denaito",
          "skm3-u1-tokoro-da-phases"
        ]
      },
      {
        "name": "Unit 2: 対象・関連 (Relation & Repetition)",
        "grammarIds": [
          "skm3-u2-toori-ni-accordance",
          "skm3-u2-ni-yotte-variation",
          "skm3-u2-tabini-repetition",
          "skm3-u2-ba-hodo-proportion",
          "skm3-u2-tsuide-ni-opportunity"
        ]
      },
      {
        "name": "Unit 3: 比較・限定 (Comparison & Boundaries)",
        "grammarIds": [
          "skm3-u3-kurai-hodo-extent",
          "skm3-u3-kurai-wa-nai",
          "skm3-u3-kurai-nara",
          "skm3-u3-ni-kagiru"
        ]
      },
      {
        "name": "Unit 4: 対比・関係 (Contrast & Relation)",
        "grammarIds": [
          "skm3-u4-hanmen-flipside",
          "skm3-u4-kawari-ni-exchange",
          "skm3-u4-ni-taishite",
          "skm3-u4-ni-kurabete"
        ]
      },
      {
        "name": "Unit 5: 原因・理由 (Causes & Reasons)",
        "grammarIds": [
          "skm3-u5-tame-ni-causality",
          "skm3-u5-koto-kara-origin",
          "skm3-u5-okage-sei"
        ]
      },
      {
        "name": "Unit 6: 条件・仮定 (Conditions & Hypotheses)",
        "grammarIds": [
          "skm3-u6-no-dakara-reality",
          "skm3-u6-tewa-dewa-negative-consequence",
          "skm3-u6-sae-ba",
          "skm3-u6-tatoe-temo"
        ]
      },
      {
        "name": "Unit 7: 目的・手段 (Purpose & Means)",
        "grammarIds": [
          "skm3-u7-you-ni-purpose",
          "skm3-u7-you-ni-suru"
        ]
      },
      {
        "name": "Unit 8: 可能・確信 (Certainty & Logic)",
        "grammarIds": [
          "skm3-u8-to-wa-kagiranai-not-necessarily",
          "skm3-u8-nai-koto-wa-nai-litotes",
          "skm3-u8-wake-ga-nai",
          "skm3-u8-wake-dewa-nai",
          "skm3-u8-wake-niwa-ikanai"
        ]
      },
      {
        "name": "Unit 9: 感情・評価 (Emotion & Evaluation)",
        "grammarIds": [
          "skm3-u9-garu",
          "skm3-u9-beki-da"
        ]
      },
      {
        "name": "形式整理 C: ところの形式 (Form C: Tokoro)",
        "grammarIds": [
          "skm3-fc-tokoro-datta"
        ]
      },
      {
        "name": "形式整理 J: 意味を広げる形式 (Suffixes & Tendencies)",
        "grammarIds": [
          "skm3-fj-ppoi-personality",
          "skm3-fj-darake-flaws",
          "skm3-fj-kimi",
          "skm3-fj-gachi"
        ]
      }
    ]
  },
  {
    "id": "skm-n2",
    "name": "Shin Kanzen Master N2 Bunpou",
    "level": "N2",
    "description": "The definitive N2 grammar manual covering all 26 core thematic chapters and supplementary functional expressions.",
    "sections": [
      {
        "name": "Chapter 10: やる・やらない (Action & Omission)",
        "grammarIds": [
          "skm2-c10-nuki-de"
        ]
      },
      {
        "name": "Chapter 11: 関係なく・無視して (Disregard & Inclusivity)",
        "grammarIds": [
          "skm2-c11-ni-kakawarazu",
          "skm2-c11-ha-tomo-kaku",
          "skm2-c11-ha-sateoki"
        ]
      },
      {
        "name": "Chapter 12: 最高・最低 (Extremes & Limits)",
        "grammarIds": [
          "skm2-c12-dokoroka"
        ]
      },
      {
        "name": "Chapter 13: 話題は (Topics & Specialties)",
        "grammarIds": [
          "skm2-c13-ni-kakete-wa"
        ]
      },
      {
        "name": "Chapter 14: 比べる (Comparison & Contrast)",
        "grammarIds": [
          "skm2-c14-ippou-de"
        ]
      },
      {
        "name": "Chapter 15: もしそうなら (Hypothetical Horizons)",
        "grammarIds": [
          "skm2-c15-mono-nara",
          "skm2-c15-nai-koto-niwa",
          "skm2-c15-wo-nuki-ni-shite-wa"
        ]
      },
      {
        "name": "Chapter 16: だから (Emotion & Reason)",
        "grammarIds": [
          "skm2-c16-amari-excess"
        ]
      },
      {
        "name": "Chapter 17: きっかけ (Catalysts & Origins)",
        "grammarIds": [
          "skm2-c17-wo-keiki-ni"
        ]
      },
      {
        "name": "Chapter 18: 原因・理由 (Objective Causes)",
        "grammarIds": [
          "skm2-c18-dakeni",
          "skm2-c18-kara-koso"
        ]
      },
      {
        "name": "Chapter 19: 逆接 (Concession & Contrast)",
        "grammarIds": [
          "skm2-c19-monono"
        ]
      },
      {
        "name": "Chapter 1: とき (Time & Occasions)",
        "grammarIds": [
          "skm2-c1-ni-saishite",
          "skm2-c1-ka-to-omou-to",
          "skm2-c1-kanai-ka-no-uchini",
          "skm2-c1-tatan-ni"
        ]
      },
      {
        "name": "Chapter 20: 結果 (Outcomes & Conclusions)",
        "grammarIds": [
          "skm2-c20-sue-ni-deliberation",
          "skm2-c20-ageku-ni"
        ]
      },
      {
        "name": "Chapter 21: 強く言う (Emphatic Assertion)",
        "grammarIds": [
          "skm2-c21-ni-kimatte-iru",
          "skm2-c21-ni-chigai-nai"
        ]
      },
      {
        "name": "Chapter 22: だろうと思う (Speculation & Probability)",
        "grammarIds": [
          "skm2-c22-osore-ga-aru",
          "skm2-c22-kane-nai",
          "skm2-c22-kaneru"
        ]
      },
      {
        "name": "Chapter 23: 感想を言う (Reflections & Essence)",
        "grammarIds": [
          "skm2-c23-mono-da-essence",
          "skm2-c23-ni-koshita-koto-wa-nai"
        ]
      },
      {
        "name": "Chapter 24: 義務・当然 (Duty & Obligation)",
        "grammarIds": [
          "skm2-c24-koto-da",
          "skm2-c24-zaru-wo-enai"
        ]
      },
      {
        "name": "Chapter 25: 強く感じる (Overwhelming Sensations)",
        "grammarIds": [
          "skm2-c25-te-wa-irarenai",
          "skm2-c25-zu-niwa-irarenai",
          "skm2-c25-te-tamaranai"
        ]
      },
      {
        "name": "Chapter 26: 敬語・待遇表現 (Polite Expressions)",
        "grammarIds": [
          "skm2-c26-te-itadaku"
        ]
      },
      {
        "name": "Chapter 2: している (Progress & Shifts)",
        "grammarIds": [
          "skm2-c2-saichuu-da",
          "skm2-c2-ippou-da-bakari-da",
          "skm2-c2-tsutsu-aru"
        ]
      },
      {
        "name": "Chapter 3: てから (Sequence & Inception)",
        "grammarIds": [
          "skm2-c3-te-hajimete",
          "skm2-c3-ue-de"
        ]
      },
      {
        "name": "Chapter 4: 範囲 (Scope & Breakthroughs)",
        "grammarIds": [
          "skm2-c4-wo-hajime",
          "skm2-c4-kara-shite",
          "skm2-c4-ni-watatte",
          "skm2-c4-kagiri-dewa"
        ]
      },
      {
        "name": "Chapter 5: だけ (Exclusivity & Limits)",
        "grammarIds": [
          "skm2-c5-nomi-narazu",
          "skm2-c5-bakari-ka"
        ]
      },
      {
        "name": "Chapter 6: について・相手にして (Topics & Targets)",
        "grammarIds": [
          "skm2-c6-ni-kansuru"
        ]
      },
      {
        "name": "Chapter 7: について・相手にして (Topics & Targets)",
        "grammarIds": [
          "skm2-c7-wo-megutte",
          "skm2-c7-ni-kotaete"
        ]
      },
      {
        "name": "Chapter 8: 視点 (Perspective & Grounds)",
        "grammarIds": [
          "skm2-c8-ni-motozuite",
          "skm2-c8-ni-sotte"
        ]
      },
      {
        "name": "Chapter 9: に関連して・に対応して (Correlation & Correspondence)",
        "grammarIds": [
          "skm2-c9-ni-tsurete",
          "skm2-c9-ni-oujite"
        ]
      },
      {
        "name": "Core Grammar",
        "grammarIds": [
          "gp-amari",
          "gp-ageku",
          "gp-mononara",
          "gp-naikotoniwa",
          "gp-monono",
          "gp-dokoroka",
          "gp-ni-kagiri",
          "gp-ni-kagitte",
          "gp-bakarika",
          "gp-ni-hokaranaranai",
          "gp-kkonai-kanenai",
          "gp-zaruwokenai",
          "gp-kato-omou-to",
          "gp-kanai-ka",
          "gp-shidai",
          "gp-to-ittara",
          "gp-wo-towazu",
          "gp-ha-tomokaku",
          "gp-ni-tsurete",
          "gp-ni-oujite"
        ]
      },
      {
        "name": "Part 2 特殊な形式 A: 〜っこない (Part 2 Form A)",
        "grammarIds": [
          "skm2-p2-kko-nai"
        ]
      },
      {
        "name": "Part 2 特殊な形式 B: 〜まい (Part 2 Form B)",
        "grammarIds": [
          "skm2-p2-mai"
        ]
      },
      {
        "name": "Part 2 特殊な形式 D: 〜まじき (Part 2 Form D)",
        "grammarIds": [
          "skm2-p2-majiki"
        ]
      },
      {
        "name": "Part 2 特殊な形式 E: 〜べからず (Part 2 Form E)",
        "grammarIds": [
          "skm2-p2-bekarazu"
        ]
      },
      {
        "name": "Part 2 特殊な形式 F: 〜甲斐 (Part 2 Form F)",
        "grammarIds": [
          "skm2-p2-kai-ga-aru"
        ]
      },
      {
        "name": "Part 2 特殊な形式 G: 〜をおいて (Part 2 Form G)",
        "grammarIds": [
          "skm2-p2-wo-oite"
        ]
      }
    ]
  }
];

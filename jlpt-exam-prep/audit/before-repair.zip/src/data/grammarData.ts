import type { GrammarPoint, StreamCategory } from '../types';
import { STREAM_CATEGORIES } from './grammarStreams';
import { STREAM_GENKI_POINTS } from './streamGenki';
import { STREAM_TIME_POINTS } from './streamTime';
import { STREAM_CAUSALITY_POINTS } from './streamCausality';
import { STREAM_CONDITIONALS_POINTS } from './streamConditionals';
import { STREAM_LIMITS_POINTS } from './streamLimits';
import { STREAM_CONTRASTS_POINTS } from './streamContrasts';
import { STREAM_MODALITY_POINTS } from './streamModality';
import { STREAM_SOCIAL_POINTS } from './streamSocial';
import { STREAM_TRENDS_POINTS } from './streamTrends';
import { STREAM_TOPICS_POINTS } from './streamTopics';

export const ALL_GRAMMAR_POINTS: GrammarPoint[] = [
  ...STREAM_GENKI_POINTS,
  ...STREAM_TIME_POINTS,
  ...STREAM_CAUSALITY_POINTS,
  ...STREAM_CONDITIONALS_POINTS,
  ...STREAM_LIMITS_POINTS,
  ...STREAM_CONTRASTS_POINTS,
  ...STREAM_MODALITY_POINTS,
  ...STREAM_SOCIAL_POINTS,
  ...STREAM_TRENDS_POINTS,
  ...STREAM_TOPICS_POINTS
];

export const GRAMMAR_BY_ID: Record<string, GrammarPoint> = ALL_GRAMMAR_POINTS.reduce(
  (acc, point) => {
    acc[point.id] = point;
    return acc;
  },
  {} as Record<string, GrammarPoint>
);

export const STREAMS: StreamCategory[] = STREAM_CATEGORIES;

export { MASTER_MUG_UP_TABLES } from './mugUpTables';
export { BOOK_SOURCES, type BookSource } from './bookCatalog';

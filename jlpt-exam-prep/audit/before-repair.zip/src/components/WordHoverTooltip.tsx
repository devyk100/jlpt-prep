import React, { useState, useRef, useEffect } from 'react';
import type { WordToken } from '../types';

interface Props {
  token: WordToken;
  furiganaMode: 'all' | 'hover' | 'off';
}

export const WordHoverTooltip: React.FC<Props> = ({ token, furiganaMode }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [coords, setCoords] = useState<{ top: number; left: number }>({ top: 0, left: 0 });
  const triggerRef = useRef<HTMLSpanElement>(null);
  const timeoutRef = useRef<number | null>(null);

  const showTooltip = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setCoords({
        top: rect.top - 8,
        left: rect.left + rect.width / 2
      });
    }
    setIsOpen(true);
  };

  const hideTooltip = () => {
    timeoutRef.current = window.setTimeout(() => {
      setIsOpen(false);
    }, 150);
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const showFuriganaAbove = furiganaMode === 'all' && token.reading && token.reading !== token.word;
  const isGrammarFocus = token.pos === 'Grammar';

  return (
    <span
      ref={triggerRef}
      onMouseEnter={showTooltip}
      onMouseLeave={hideTooltip}
      onClick={() => setIsOpen(prev => !prev)}
      className={`inline-block relative cursor-pointer mx-[1px] px-1 py-0.5 rounded transition-colors select-none ${
        isGrammarFocus
          ? 'bg-[#eef2ea] border-b-2 border-[#467b6b] font-medium text-[#1e2d26]'
          : 'hover:bg-[#edece1] border-b border-dotted border-[#b8bfb0] hover:border-[#467b6b]'
      }`}
    >
      <ruby className="ruby-text">
        <span className="text-[1.05rem] leading-none text-[#24332c]">{token.word}</span>
        {showFuriganaAbove && (
          <rt className="text-[0.62rem] text-[#788278] font-normal select-none">
            {token.reading}
          </rt>
        )}
      </ruby>

      {isOpen && (
        <div
          style={{
            position: 'fixed',
            top: `${coords.top}px`,
            left: `${coords.left}px`,
            transform: 'translate(-50%, -100%)',
            zIndex: 9999
          }}
          className="w-64 max-w-[90vw] p-3 rounded-lg bg-[#fffef9] text-[#283b35] shadow-xl border border-[#c5cebc] pointer-events-auto text-left text-xs animate-in fade-in duration-100"
          onMouseEnter={() => {
            if (timeoutRef.current) clearTimeout(timeoutRef.current);
          }}
          onMouseLeave={hideTooltip}
        >
          {/* Header with Reading and POS */}
          <div className="flex items-start justify-between gap-2 border-b border-[#e8e9df] pb-1.5 mb-1.5">
            <div>
              <div className="text-base font-serif-ja font-bold text-[#1e2d26] flex items-baseline gap-1.5">
                <span>{token.word}</span>
                {token.reading && token.reading !== token.word && (
                  <span className="text-xs font-normal text-[#617066]">【{token.reading}】</span>
                )}
              </div>
              {token.romaji && (
                <div className="text-[10px] text-[#8a9485] font-mono">{token.romaji}</div>
              )}
            </div>

            {token.pos && (
              <span className={`text-[9px] px-1.5 py-0.5 rounded font-semibold uppercase ${
                token.pos === 'Grammar'
                  ? 'bg-[#e7edde] text-[#496445]'
                  : 'bg-[#edebe0] text-[#617066]'
              }`}>
                {token.pos}
              </span>
            )}
          </div>

          {/* Meaning / English Definition */}
          <div className="text-xs text-[#283b35] font-medium leading-relaxed mb-1">
            {token.meaning}
          </div>

          {/* Nuance Note or JLPT Trap */}
          {token.nuance && (
            <div className="mt-1.5 pt-1.5 border-t border-[#e8e9df] text-[10.5px] text-[#7c633a] leading-tight flex items-start gap-1">
              <span className="font-bold shrink-0">Note:</span>
              <span>{token.nuance}</span>
            </div>
          )}

          {/* Subtle bottom arrow */}
          <div className="absolute left-1/2 -bottom-1 -translate-x-1/2 w-2 h-2 bg-[#fffef9] border-r border-b border-[#c5cebc] rotate-45" />
        </div>
      )}
    </span>
  );
};
